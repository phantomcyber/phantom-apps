"""
darkpointrest.exceptions
~~~~~~~~~~~~~~~~~~~~~~~~

This module contains the set of DarkpointRest exceptions.

"""
import logging

logging.getLogger("darkpointrest.exception")

class DarkpointRESTException( Exception ):
    """
    Exception raised for DarkPoint REST API errors.

    Attributes:
        * **response**: Full HTTP response
        * **code**: HTTP response code
        * **headers**: HTTP response headers
        * **body**: HTTP response body
        * **status**: DarkPoint REST API error status code
        * **message**: DarkPoint REST API error message
    """    
    def __init__(self, response, *args):
        super(DarkpointRESTException, self).__init__(response, *args)

        self.response = response
        self.code = self.response.code
        self.headers = self.response.headers
        self.body = None
        self.message = None
        self.status = None
        if (response is not None and not self.body and
                hasattr(response, 'body')):
            if isinstance(self.response.body, dict):
                self.body = self.response.body
                self.status = self.body["status"]
                self.message = self.body["message"]
                logging.debug("HTTP headers: %s" % self.headers)
                logging.debug("%s (status code: %s)" % (self.message, self.status))
            else:
                logging.debug(response.body)

    def __str__(self):
        if not self.message or not self.status:
            return "HTTP error %s: %s" % (self.code, self.response.body)
        else:
            return "%s (HTTP error: %s, status code: %s)" % (self.message, self.code, self.status)


class CredentialsError( DarkpointRESTException ):
    """Credentials Needed"""


class AuthenticationError( DarkpointRESTException ):
    """Authentication Needed"""
        
