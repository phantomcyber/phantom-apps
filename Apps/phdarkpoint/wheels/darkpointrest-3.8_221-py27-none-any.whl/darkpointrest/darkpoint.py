"""
.. module:: darkpoint.py
   :platform: Unix, Windows
   :synopsis: Python client for Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import logging
import logging.config
import threading
import urllib
from urlparse import urlparse

import unirest

from exceptions import *
from exceptions.validation import ValidationError
from controllers.artifact import Artifact, Sort
from controllers.admin import Admin, Role
from controllers.search import Search
from controllers.user import User
from controllers.workflow import Workflow
# from controllers.whitelist import Whitelist


class Darkpoint(object):
    """
    Summary:
        Initializes the DarkPoint REST client

    Args:
        * **user**: Username of the DarkPoint account
        * **password**: Password of the DarkPoint account
        * **host**: URL connection string (including 'https://' or 'http://') of the DarkPoint server [optional]
        * **timeout**: Timeout in seconds for REST calls (defaults to 60 seconds) [optional]

    Returns:
        A DarkPoint client connection object with the following
        REST API interfaces:

        1. :py:class:`darkpoint.admin <darkpointrest.controllers.admin>`
        2. :py:class:`darkpoint.artifact <darkpointrest.controllers.artifact>`
        3. :py:class:`darkpoint.search <darkpointrest.controllers.search>`
        4. :py:class:`darkpoint.user <darkpointrest.controllers.user>`
        5. :py:class:`darkpoint.workflow <darkpointrest.controllers.workflow>`

    Raises:
        AuthenticationError: Errors when authenticating to DarkPoint

    """
    def __init__(self, user, password, host='https://app.darkpoint.us', timeout=60):
        self.logger = logging.getLogger('darkpointrest')

        user_credentials = {
            'username': urllib.quote(user.encode("utf-8")),
            'password': urllib.quote(password.encode("utf-8"))
        }

        if user is None or password is None:
            raise ValidationError("You MUST supply a username and password to connect to DarkPoint!")

        self.validate_host(host)

        aux_headers = {'darkpoint-source': 'python/restclient'}
        self.host = host

        login_endpoint_url = self.host + '/api/login'

        unirest.timeout(timeout)     # Set default timeout for calls

        try:
            self.response = unirest.post(
                login_endpoint_url,
                headers=aux_headers,
                params=user_credentials,
                callback=None)
        except:
            raise ValidationError("Unable to connect to DarkPoint API server!")

        self.logger.debug("Authentication response body: %s" % self.response.body)
        self.logger.debug("Authentication response headers: %s" % self.response.headers)

        if self.response.code is 200:
            self.auth_cookie = self.response.headers['set-cookie']
            self.logger.debug("self.auth_cookie: %s" % self.auth_cookie)

            # Initialize Darkpoint APIs
            self.artifact = Artifact(self.host, self.auth_cookie)
            self.admin = Admin(self.host, self.auth_cookie)
            self.search = Search(self.host, self.auth_cookie)
            self.user = User(self.host, self.auth_cookie)
            self.workflow = Workflow(self.host, self.auth_cookie, user)
            self.role = Role()
            self.sort = Sort()
            # self.whitelist = Whitelist(self.host, self.auth_cookie)
        else:
            raise AuthenticationError(self.response)

        # Start a periodic 2 minute timer thread to keep our auth_cookie active
        self._clientPingTimer = RepeatedTimer(120, self.cookie_keep_alive)

    def validate_host(self, host):
        o = urlparse(host)

        if o.scheme not in ['http', 'https']:
            raise ValidationError("'host=' connection string must start with proper protocol: 'http://' or 'https://'")
        # Can't use o.port because an invalid port returns None
        netloc = o.netloc.split('@')[-1].split(']')[-1]
        if ':' in netloc:
            port = netloc.split(':')[1]
            if port:
                port = int(port, 10)
                # verify legal port
                if port < 0 or port > 65535:
                    raise ValidationError("'host=' connection string must include a valid port or omit port to use protocol default!")

    def cookie_keep_alive(self):
        """ Makes a call to ensure the authenication cookie remains current.
        """
        auth_user = self.host + '/api/auth/user'

        response = unirest.get(
            auth_user,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'}
        )

        if response.code is not 200:
            self.logger.error("Failed to make auth/user call for cookie keep alive (%s)" % response.code)
            raise DarkpointRESTException(response)


class RepeatedTimer(object):
    """ Small thread class to continueally reschedule a periodic function
    """
    def __init__(self, interval, function, *args, **kwargs):
        self._timer = None
        self.interval = interval
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.is_shutdown = False
        self.start()

    def _run(self):
        self.function(*self.args, **self.kwargs)
        if self.is_shutdown is False:
            self.start()

    def start(self):
        self._timer = threading.Timer(self.interval, self._run)
        self._timer.daemon = True
        self._timer.start()

    def stop(self):
        self._timer.cancel()
        self.is_shutdown = True
