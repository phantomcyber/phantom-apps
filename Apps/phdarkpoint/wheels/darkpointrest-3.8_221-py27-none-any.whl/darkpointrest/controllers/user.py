"""
.. module:: user.py
   :platform: Unix, Windows
   :synopsis: Python client for User Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import unirest
import json
import logging
from darkpointrest.exceptions import DarkpointRESTException
from darkpointrest.exceptions.validation import ValidationError


class User(object):

    def __init__(self, darkpoint_server, auth_cookie):
        self.darkpoint_server = darkpoint_server
        self.auth_cookie = auth_cookie
        self.logger = logging.getLogger('darkpointrest.user')


    def set_password(self, password, callback=None):
        """
        Summary:
            Sets the password for the authenticated user in DarkPoint

        Args:
            password (str): New password for the authenticated user
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/user/password'

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            params=json.dumps({'password': password}),
            callback=callback)

        if response.code is 200:
            self.logger.info("Password updated successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update password (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_current_groups(self, callback=None):
        """
        Summary:
            Gets the current groups for the authenticated user in DarkPoint

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            list: List of current groups

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/user/current-groups'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'},
            callback=callback)

        if response.code is 200:
            self.logger.info("Successfully retrieved current groups (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update password (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_current_groups(self, group, callback=None):
        """
        Summary:
            Updates the currently selected group for the authenticated user in DarkPoint

        Args:
            group (str): List of valid groups to which the authenticated user will belong
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response
            ValidationError: If group is not a string or list of length 1

        """
        endpoint = self.darkpoint_server + '/api/auth/user/current-groups'

        if isinstance(group, basestring):
            group = [group]
        elif len(group) > 1:
            raise ValidationError("group must be a string or list of length 1")

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            params=json.dumps(group),
            callback=callback)

        if response.code is 200:
            self.logger.info("Successfully updated current groups (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update current groups (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_custom_workflows(self, callback=None):
        """
        Summary:
            Retrieves the custom workflows for the user

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            list: List of custom workflows

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/user/custom-workflows'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            callback=callback)

        if response.code is 200:
            self.logger.info("Successfully updated current groups (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update current groups (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_custom_workflow(self, name, analyzers, options={}, callback=None):
        """
        Summary:
            Sets a custom workflow

        Args:
            name (str): Name of the workflow
            analyzers (list): The analyzers to include in the workflow
            options (dict): (Optional) The options to include for each analyzer. :py:class:`.Role`
                Key'd by analyzer name.  Use the options as returned by :func:`~darkpointrest.controllers.workflow.Workflow.list_analyzers`
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            dict: includes a 'status' and 'message'

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/user/custom-workflow'

        body = {
            'workflowName': name,
            'analyzers': analyzers,
            'options': options
        }

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            params=json.dumps(body),
            callback=callback)

        if response.code is 200:
            self.logger.info("Successfully updated current groups (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update current groups (%s)" % response.code)
            raise DarkpointRESTException(response)


    def delete_custom_workflows(self, names, callback=None):
        """
        Summary:
            Delete a custom workflow

        Args:
            names (str) or (list): A custom workflow name (or list of names) to delete
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            dict: includes a 'status' and 'message'

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/user/custom-workflows/delete'


        if isinstance(names, basestring):
            names = [names]

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            params=json.dumps(names),
            callback=callback)

        if response.code is 200:
            self.logger.info("Successfully updated current groups (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to update current groups (%s)" % response.code)
            raise DarkpointRESTException(response)
