"""
.. module:: workflow.py
   :platform: Unix, Windows
   :synopsis: Python client for Workflow Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import unirest
import json
import logging
from darkpointrest.exceptions import DarkpointRESTException


class Workflow(object):

    def __init__(self, darkpoint_server, auth_cookie, user):
        self.darkpoint_server = darkpoint_server
        self.auth_cookie = auth_cookie
        self.user = user
        self.logger = logging.getLogger('darkpointrest.workflow')

    def list_workflows(self, callback=None):
        """
        Summary:
            Retrieve the list of available workflows

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            list: A list of workflow dictionaries (name and analyzers in each workflow)

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/workflow'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            callback=callback)

        workflows = response.body

        self.logger.info("Workflows returned from API: %s" % workflows)
        for wf in workflows:
            if wf["name"] == "AbstractAnalyzer":
                workflows.remove(wf)

        if response.code is 200:
            self.logger.info("Workflow list retrieved successfully (%s)" % response.code)
            return workflows
        else:
            self.logger.error("Failed to retrieve workflow list (%s)" % response.code)
            raise DarkpointRESTException(response)

    def list_intelligent_workflows(self, callback=None):
        """
        Summary:
            Retrieve the list of created intelligent workflows for the currently authenticated user

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            list: A list of workflow dictionaries consisting of each intelligent workflow's
                id, dateUpdated, and generatedXML (BPMN file)

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/workflow/intelligent-workflow'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            callback=callback)

        workflows = response.body

        self.logger.info("%d intelligent workflows returned from API for this user: %s" % 
                         (len(workflows), workflows))

        if response.code is 200:
            self.logger.info("Intelligent workflow list retrieved successfully (%s)" % response.code)
            return workflows
        else:
            self.logger.error("Failed to retrieve intelligent workflow list (%s)" % response.code)
            raise DarkpointRESTException(response)

    def list_analyzers(self, callback=None):
        """
        Summary:
            Retrieve the list of available analyzers

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            list: Analyzers and their supporting options

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/workflow/analyzers'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            callback=callback)

        if response.code is 200:
            self.logger.info("Workflow list retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve workflow list (%s)" % response.code)
            raise DarkpointRESTException(response)

    def submit(self, sha1, workflow=None, analyzers=[], options={}, callback=None):
        """
        Summary:
            Submit a workflow to DarkPoint. Requires either workflow or analyzer list \
            be specified.

        Args:
            sha1 (str) or (list): The SHA1 (or list of SHA1s) to operate on
            workflow (str): (Optional) Name of the built-in workflow (retrieved from list_workflows),
                or the ID of the intelligent workflow (retrieved from list_intelligent_workflows)
                to be invoked
            analyzers (list): (Optional) In the absence of a specified workflow, a list of analyzers
                to run on the SHA1
            options (dict): A dictionary of options lists for each analyzer
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            str: UUID of the workflow job on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/workflow/submit'

        if isinstance(sha1, basestring):
            sha1 = [sha1]

        workflow_submission = {"sha1": sha1,
                               "analyzers": analyzers,
                               "options": options,
                               "workflow": workflow}

        if not workflow or len(analyzers) > 0:
            workflow_submission.pop("workflow")

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            params=json.dumps([workflow_submission]),
            callback=callback)

        if response.code is 200:
            self.logger.info("Workflow on artifact %s submitted successfully (%s)" % (sha1, response.code))
            return response.body[0]["uuid"]
        else:
            self.logger.error("Failed to submit workflow on artifact %s (%s)" % (sha1, response.code))
            raise DarkpointRESTException(response)


    def cancel(self, uuid, callback=None):
        """
        Summary:
            Cancel a running DarkPoint workflow

        Args:
            uuid (str): UUID of the workflow to cancel
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/workflow/' + uuid

        response = unirest.delete(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'},
            callback=callback)

        if response.code is 200:
            self.logger.info("Workflow %s canceled successfully (%s)" % (uuid, response.code))
            return response.body
        else:
            self.logger.error("Failed to cancel workflow %s (%s)" % (uuid, response.code))
            raise DarkpointRESTException(response)


    def status(self, users=None, sha1s=None, workflowIds=None, uuids=None, refresh=None, count=None,
               page=None, sort=None, reverse=None, callback=None):
        """
        Summary:
            Get the status of DarkPoint workflows

        Args:
            users: List of users for which their workflow statuses will be retrieved [optional]
            sha1s: List of SHA1s for which their workflow statuses will be retrieved [optional]
            workflowIds: List of workflow IDs for which their statuses will be retrieved [optional]
            uuids: List of workflow UUIDs for which their status will be retrieved [optional]
            refresh: Request a hard Refresh of the status instead of using the periodicly updated cache [optional]
            count: Number of results to return per page [optional]
            page: Specify which page of results to return [optional]
            sort: Specify sort method for returned results (see :py:class:`.Sort` class) [optional]
            reverse: Reverse the sort order of returned results [optional]
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            JSON body of workflow status

        Raises:
            DarkpointRestException: REST API error response

        """
        status_endpoint_url = self.darkpoint_server + '/api/auth/workflow/status'

        body = {
            'requestType': 'status',
            'page': 0,
            'sort': 'queued',
            'reverse': True
        }
        if users is not None:
            body['users'] = users
            if not isinstance(users, list):
                raise TypeError("users - expected type 'list'")
        if sha1s is not None:
            body['sha1s'] = sha1s
        if workflowIds is not None:
            body['workflowIds'] = workflowIds
            if not isinstance(workflowIds, list):
                raise TypeError("workflowIds - expected type 'list'")
        if sha1s is not None:
            body['sha1s'] = sha1s
            if not isinstance(sha1s, list):
                raise TypeError("sha1s - expected type 'list'")
        if uuids is not None:
            if not isinstance(uuids, list):
                raise TypeError("uuids - expected type 'list'")
            body['uuids'] = uuids
        if refresh is not None:
            body['refresh'] = refresh
        if count is not None:
            body['count'] = count
        if page is not None:
            body['page'] = page
        if sort is not None:
            body['sort'] = sort
        if reverse is not None:
            body['reverse'] = reverse

        self.logger.debug("Paramter JSON: %s" % json.dumps(body))

        response = unirest.post(status_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                         'Cookie': self.auth_cookie,
                                         'Content-Type': 'application/json',
                                         'Accept': 'application/json'},
                                params=json.dumps(body),
                                callback=callback)

        if response.code is 200:
            self.logger.info("Workflow status retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve workflow status (%s)" % response.code)
            raise DarkpointRESTException(response)
