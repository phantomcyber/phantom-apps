"""
.. module:: search.py
   :platform: Unix, Windows
   :synopsis: Python client for Search Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import unirest
import json
import logging
from darkpointrest.exceptions import DarkpointRESTException


class Binding(object):
    """
    Summary:
        Binding object for a DarkPoint search query

    Args:
        * **json_binding**: Initialized with a binding from the JSON template schema or subquery entity

    Returns:
        Binding object for use within :py:class:`.Template` or :py:class:`.Subquery` object

    Members:
        * **name**: Name of the binding element
        * **title**: Title of the binding element
        * **type**: Type associated with the binding element
        * **description**: Description of the binding element

        .. note:: Binding object may contain :py:attr:`.value` or \
        :py:attr:`.value_start`, :py:attr:`.value_end` member variables

        * **value**: Field containing the search term to be filled \
        in by the user.
        * **value_start**: Field containing the start value of the \
        search term to be filled in by the user
        * **value_end**: Field containing the end value of the \
        search term to be filled in by the user

    Raises:
        None

    """
    def __init__(self, json_binding):
        self.json_binding = json_binding
        self.description = json_binding["description"]
        self.name = json_binding["name"]
        self.title = json_binding["title"]
        self.type = json_binding["type"]
        if "value" in json_binding:
            self.value = json_binding["value"]
        elif ("valueStart" in json_binding) and ("valueEnd" in json_binding):
            self.value_start = json_binding["valueStart"]
            self.value_end = json_binding["valueEnd"]

    def __str__(self):
        return json.dumps(self.json_binding, indent=4, sort_keys=True)


class Subquery(object):
    """
    Summary:
        Subquery object for a DarkPoint search query

    Args:
        * **json_subquery**: Initialized with a subquery from the \
        JSON template schema subqueries list

    Returns:
        Subquery object for use within :py:class:`.Template` object

    Members:
        * **bindings**: The data bindings associated with this subquery
        * **name**: Name of the binding element
        * **function**: Function associated with this subquery
        * **functions**: JSON-formatted representation of the Elasticsearch \
        functions performed for this subquery

    Raises:
        None

    """
    def __init__(self, json_subquery):
        self.json_subquery = json_subquery
        self.name = json_subquery["name"]
        self.bindings = [Binding(binding) for binding in json_subquery["bindings"]]
        self.function = json_subquery["function"]
        self.functions = json_subquery["functions"]

    def __str__(self):
        return json.dumps(self.json_subquery, indent=4, sort_keys=True)

    def to_json(self):
        # Update the R/W fields and return JSON
        self.json_subquery["bindings"] = [binding.__dict__ for binding in self.bindings]
        return self.json_subquery


class Template(object):
    """
    Summary:
        Search template object for the DarkPoint REST client search API

    Args:
        * **json_template**: Initialized with a template from the \
        schema retrieved from DarkPoint

    Returns:
        Template object for use within :py:class:`.Schema` object

    Members:
        * **id**: Template ID
        * **name**: Name of the template
        * **title**: Title of the template
        * **type**: Type of search template
        * **description**: Description of the search template
        * **indices**: Indices that are included as part of this search template
        * **elasticsearch_query**: JSON-formatted Elasticsearch query executed by this template
        * **fusion_action**: Action performed if results are to be merged
        * **subqueries**: List of queries if this template contains multiple queries
        * **bindings**: Information elements provided by the user which will represent the \
        input (i.e., search terms) to the query (or subqueries). In the case of subqueries, \
        bindings will appear under each subquery entry

    Raises:
        None

    """
    def __init__(self, json_template):
        self.json_template = json_template
        self.id = json_template["_id"]
        self.description = json_template["description"]
        self.elasticsearch_query = json_template["elasticsearchQuery"]
        self.indices = [index for index in json_template["indices"]]
        self.name = json_template["name"]
        self.type = json_template["type"]
        self.title = json_template["title"]

        if "fusion_action" in json_template:
            self.fusion_action = json_template["fusion_action"]

        if "bindings" in json_template:
            self.bindings = [Binding(binding) for binding in json_template["bindings"]]
        elif "subQueries" in json_template:
            self.subqueries = [Subquery(subquery) for subquery in json_template["subQueries"]]

    def to_json(self):
        #Update the R/W fields and return JSON string
        if "bindings" in self.json_template:
            self.json_template["bindings"] = [binding.__dict__ for binding in self.bindings]
        elif "subQueries" in self.json_template:
            self.json_template["subQueries"] = [subquery.to_json() for subquery in self.subqueries]
        return json.dumps(self.json_template)



class Schema(object):
    """
    Summary:
        Search schema object for the DarkPoint REST client search API

    Args:
        * **json_schema**: Initialized with the latest schema retrieved from DarkPoint

    Returns:
        Schema object containing a list of :py:class:`.Template` objects

    Members:
        * **templates**: Dictionary of :py:class:`.Template` objects keyed by name
        * **index**: List of template names contained in schema

    Raises:
        None

    """
    def __init__(self, json_schema):
        self.templates = {}
        for template in json_schema:
            t = Template(template)
            self.templates[t.name.encode()] = t
        self.index = [key.encode() for key in self.templates.keys()]


class Search(object):

    def __init__(self, darkpoint_server, auth_cookie):
        self.darkpoint_server = darkpoint_server
        self.auth_cookie = auth_cookie
        self.logger = logging.getLogger('darkpointrest.search')

    def get_schema(self, callback=None):
        """
        Summary:
            Retrieves the search schema from DarkPoint

        Args:
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            DarkPoint search schema as :py:class:`.Schema` object

        Raises:
            DarkpointRestException: REST API error response

        """
        get_schema_endpoint_url = self.darkpoint_server + '/api/auth/search/schema'

        response = unirest.get(get_schema_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/json'},
                              callback=callback)

        if response.code is 200:
            self.logger.info("Search schema retrieved successfully (%s)" % response.code)
            return Schema(response.body)
        else:
            self.logger.error("Search schema retrieval failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def execute(self, template, callback=None):
        """
        Summary:
            Executes a DarkPoint search

        Args:
            * **search_template**: Search template as :py:class:`.Template` object
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Search results as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        assert isinstance(template, Template),"%r is not a Template object" % template

        execute_search_endpoint_url = self.darkpoint_server + '/api/auth/search/execute'

        response = unirest.post(execute_search_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/json'},
                              params=template.to_json(),
                              callback=callback)

        if response.code is 200:
            self.logger.info("Search executed successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Search execution failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def simple_search(self, search_term, callback=None):
        """
        Summary:
            Executes a simple DarkPoint search using the GenericQuery template

        Args:
            * **search_term**: Search term to be used in the query
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Search results as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        generic_query_template = self.get_schema().templates["GenericQuery"]
        generic_query_template.subqueries[0].bindings[0].value = search_term
        generic_query_template.subqueries[0].function = "contains"

        execute_search_endpoint_url = self.darkpoint_server + '/api/auth/search/execute'

        response = unirest.post(execute_search_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/json'},
                              params=generic_query_template.to_json(),
                              callback=callback)

        if response.code is 200:
            self.logger.info("Search executed successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Search execution failed (%s)" % response.code)
            raise DarkpointRESTException(response)
