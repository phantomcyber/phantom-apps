"""
.. module:: admin.py
   :platform: Unix, Windows
   :synopsis: Python client for Admin Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import unirest
import json
import logging
from darkpointrest.exceptions import DarkpointRESTException


class Role(object):
    """
    Summary:
        Class representing enumerated values of Role fields.

    Members:
        * **USER**
        * **ADMIN**
        * **DOWNLOAD**
        * **DELETE**
        * **DEVELOPER**
        * **INVESTIGATOR**
        * **CASE_MANAGER**
        * **CASE_MANAGER_ADMIN**
    """
    def __init__(self):
        self.USER = 'USER'
        self.ADMIN = 'ADMIN'
        self.DOWNLOAD = 'DOWNLOAD'
        self.DELETE = 'DELETE'
        self.DEVELOPER = 'DEVELOPER'
        self.INVESTIGATOR = 'INVESTIGATOR'
        self.CASE_MANAGER = 'CASE_MANAGER'
        self.CASE_MANAGER_ADMIN = 'CASE_MANAGER_ADMIN'
        

role = Role()


class Admin(object):

    def __init__(self, darkpoint_server, auth_cookie):
        self.darkpoint_server = darkpoint_server
        self.auth_cookie = auth_cookie
        self.logger = logging.getLogger('darkpointrest.admin')


    def add_user(self, username, password, email, groups=['PUBLIC'], roles=None, callback=None):
        """
        Summary:
            Adds a user to DarkPoint

            These options will need to be specifed in the User object being passed:

        Args:
            username (str): Username of the account to be added. Must be at least 5 characters,
                and may have uppercase, lowercase, numbers, and symbols
            password (str): Password of the account to be added. Must be at least 8 characters with
                one capital letter, one number and one special character
            email (str): Email address for the account. Must be valid format
            groups (list): (Optional) List of groups to which this user account will belong
            roles (dict): (Optional) Dict of {group: [roles]} assigned to this user (see enum class :py:class:`.Role`).
                By default, the 'User' role is granted for the PUBLIC and private groups.
                Other available roles include: Administrator, Delete, Developer, Download,
                Intelligent Workflow Manager, Intelligent Workflow User, Upload
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        # default groups and roles
        private_group = username.upper()
        if private_group not in groups:
            groups.append(private_group)
        if "PUBLIC" not in groups:
            groups.append("PUBLIC")

        roles_to_add = [
                         {"group": private_group,
                          "role": role.USER,
                          "context": "ALL"},
                         {"group": "PUBLIC",
                          "role": role.USER,
                          "context": "ALL"}
                       ]
        
        # we need to make sure that for any custom group added, we add a role too
        for g in groups:
            if not any(skip in g for skip in ('PUBLIC', private_group)):
                if roles is None:
                    roles = {}
                if g not in roles.keys():
                    roles[g] = ['USER']
        
        # if additional roles requested for group(s), append here. assume ALL context.
        # case management roles return a 400, so comment out that logic for now.
        if roles is not None:
            for g in roles.keys():
                roles_for_g = [r.upper() for r in roles[g]]
                if 'USER' not in roles[g]:
                    roles_for_g.append('USER')

                for r in roles_for_g:
                    assert(any(role in r for role in Role().__dict__.values()))

                    """if any(cm in r for cm in ('CASE_MANAGER',
                                              'CASE_MANAGER_ADMIN',
                                              'INVESTIGATOR')):
                        add_me = {"group": g.upper(), "role": r, "context": "CASE_MANAGEMENT"}
                    else: """
                    add_me = {"group": g.upper(), "role": r, "context": "ALL"}

                    if add_me not in roles_to_add:
                        roles_to_add.append(add_me)
        
        add_user_endpoint_url = self.darkpoint_server + '/api/auth/admin/user'

        response = unirest.post(add_user_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                params=json.dumps({'username': username,
                                                'password': password,
                                                'email': email,
                                                'groups': groups,
                                                'roles': roles_to_add}),
                                callback=callback)

        if response.code is 200:
            self.logger.info("User '%s' created successfully (%s)" % (username, response.code))
            return response.body
        else:
            self.logger.error("Failed to create user '%s' (%s)" % (username, response.code))
            raise DarkpointRESTException(response)


    def update_user(self, username, **kwargs):
        """
        Summary:
            Updates a DarkPoint user

        Args:
            username (str): Username of the account to be modified
            password (str): (Optional) Password of the account to be added. Must be at least 8 characters with
                one capital letter, one number and one special character
            groups (list): (Optional) List of groups to which this user account will belong
            roles (dict): (Optional) Dict of {group: [roles]} assigned to this user (see enum class :py:class:`.Role`)
            deleted (bool): (Optional) Boolean indicating whether an account is active (true) or not (false)
            userOptions (dict): (Optional) User options to include, e.g.: {"defaultGroups": ["default_group_choice"]}
            fullname (str): (Optional) Full name assigned to this user
            email (str): (Optional) Email address assigned to this user
            phone (str): (Optional) Phone number assigned to this user
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        update_user_endpoint_url = self.darkpoint_server + '/api/auth/admin/user/update'

        if "callback" in kwargs:
            callback = kwargs["callback"]
            kwargs.pop("callback")
        else:
            callback = None

        body = {}
        body["username"] = username
        for key, value in kwargs.iteritems():
            if key == "roles":
                roles = value
                roles_to_add = [
                                {"group": username.upper(),
                                  "role": role.USER,
                                  "context": "ALL"},
                                 {"group": "PUBLIC",
                                  "role": role.USER,
                                  "context": "ALL"}
                               ]
                # we need to make sure that for any custom group added, we add a role too
                if "groups" in kwargs.keys():
                    for g in kwargs["groups"]:
                        if not any(skip in g for skip in ('PUBLIC', username.upper())):
                            if g not in roles.keys():
                                roles[g] = ['USER']
                
                # if additional roles requested for group(s), append here. assume ALL context.
                if roles is not None:
                    for g in roles.keys():
                        roles_for_g = [r.upper() for r in roles[g]]
                        if 'USER' not in roles[g]:
                            roles_for_g.append('USER')
        
                        for r in roles_for_g:
                            assert(any(role in r for role in Role().__dict__.values()))
        
                            add_me = {"group": g.upper(), "role": r, "context": "ALL"}
        
                            if add_me not in roles_to_add:
                                roles_to_add.append(add_me)
                                
                body["roles"] = roles_to_add
            else:
                body[key] = value
                if key == "groups":
                    for g in [username.upper(), 'PUBLIC']:
                        if g not in body[key]:
                            body[key].append(g)


        self.logger.debug("Parameter JSON: %s" % json.dumps(body))
        self.logger.debug("REST body JSON: %s" % json.dumps({"user":body}))

        response = unirest.post(update_user_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                params=json.dumps(body),
                                callback=callback)

        if response.code is 200:
            self.logger.info("Update for user '%s' successful (%s)" % (username, response.code))
            return response.body
        else:
            self.logger.error("Update for user '%s' failed (%s)" % (username, response.code))
            raise DarkpointRESTException(response)


    def delete_user(self, username, callback=None):
        """
        Summary:
            Delete a DarkPoint user

        Args:
            username (str): Username to be deleted
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        delete_user_endpoint_url = self.darkpoint_server + '/api/auth/admin/user/' + username
        response = unirest.delete(delete_user_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                callback=callback)

        if response.code is 200:
            self.logger.info("User '%s' deleted successfully (%s)" % (username, response.code))
            return response.body
        else:
            self.logger.error("Failed to delete user '%s' (%s)" % (username, response.code))
            raise DarkpointRESTException(response)


    def list_users(self, callback=None):
        """
        Summary:
            List all DarkPoint users

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            User information

        Raises:
            DarkpointRestException: REST API error response

        """

        get_users_endpoint_url = self.darkpoint_server + '/api/auth/admin/user'
        response = unirest.get(get_users_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                callback=callback)

        if response.code is 200:
            self.logger.info("User information retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve user information (%s)" % response.code)
            raise DarkpointRESTException(response)


    def list_user(self, username, callback=None):
        """
        Summary:
            List information for single DarkPoint user

        Args:
            username (str): Username to retrieve
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            User information

        Raises:
            DarkpointRestException: REST API error response

        """
        get_users_endpoint_url = self.darkpoint_server + '/api/auth/admin/user/' + username
        response = unirest.get(get_users_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                callback=callback)

        if response.code is 200:
            self.logger.info("User information retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve user information (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_analyzer_config(self, analyzer, callback=None):
        """
        Summary:
            Retrieve configuration for a DarkPoint analyzer

        Args:
            analyzer (str): Analyzer to retrieve
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            dict: Analyzer configuration

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/analyzer-configuration/' + analyzer

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Analyzer configuration retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve analyzer configuration (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_analyzer_config(self, analyzer, config, callback=None):
        """
        Summary:
            Update the configuration for an analyzer

        Args:
            analyzer (str): Analyzer name
            config (dict): Full analyzer configuration to be set.
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/analyzer-configuration/' + analyzer

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            params=json.dumps(config),
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Analyzer '%s' created successfully (%s)" % (analyzer, response.code))
            return True
        else:
            self.logger.error("Failed to set analyzer config '%s' (%s)" % (analyzer, response.code))
            raise DarkpointRESTException(response)


    def get_analyzer_template(self, analyzer, callback=None):
        """
        Summary:
            Get analyzer UI template for a DarkPoint analyzer

        Args:
            analyzer (str): Analyzer to retrieve
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            str: Serialized analyzer UI template

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/analyzer-template/' + analyzer

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'text/html'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Analyzer template retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve analyzer template (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_analyzer_template(self, analyzer, template, callback=None):
        """
        Summary:
            Set the UI template for an analyzer

        Args:
            analyzer (str): Analyzer name
            template (str): Serialized analyzer UI template to be set
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/analyzer-template/' + analyzer

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'text/html'
            },
            params=template,
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Analyzer '%s' successfully set (%s)" % (analyzer, response.code))
            return True
        else:
            self.logger.error("Failed to set analyzer template '%s' (%s)" % (analyzer, response.code))
            raise DarkpointRESTException(response)


    def get_motd(self, callback=None):
        """
        Summary:
            Retrieve message of the day

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            dict: Message of the day content

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/motd'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Message of the day retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve message of the day (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_motd(self, messagetext, callback=None):
        """
        Summary:
            Update the message of the day

        Args:
            messagetext (str): Message of the day content as HTML or a string
                (non-HTML will be embedded in paragraph tags)
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/motd'

        if not messagetext.startswith('<'):
            messagetext = '<p>' + messagetext + '</p>'

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            params=json.dumps({"message": messagetext}),
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Message of the day updated successfully (%s)" % (response.code))
            return True
        else:
            self.logger.error("Failed to update message of the day with the text '%s' (%s)" % (messagetext, response.code))
            raise DarkpointRESTException(response)


    def get_eula(self, callback=None):
        """
        Summary:
            Retrieve the EULA

        Args:
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            dict: EULA content and version

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/eula'

        response = unirest.get(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("EULA retrieved successfully (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Failed to retrieve the EULA (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_eula(self, eulatext, version, resetUsers=False, callback=None):
        """
        Summary:
            Update the EULA

        Args:
            eulatext (str): Message of the day content as HTML or a string
                (non-HTML will be embedded in paragraph tags)
            version (str): EULA version number
            resetUsers (bool): Whether to force users to accept the new EULA at next login
            callback (function): (Optional) User-defined callback function for asynchronous operation

        Returns:
            True on success

        Raises:
            DarkpointRestException: REST API error response

        """
        endpoint = self.darkpoint_server + '/api/auth/admin/eula'

        if not eulatext.startswith('<'):
            eulatext = '<p>' + eulatext + '</p>'

        response = unirest.post(
            endpoint,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json'
            },
            params=json.dumps({"eula": eulatext,
                               "version": version,
                               "resetUsers": resetUsers}),
            callback=callback
        )

        if response.code is 200:
            self.logger.info("EULA updated successfully (%s)" % (response.code))
            return True
        else:
            self.logger.error("Failed to update EULA with the text '%s' and version '%s' (%s)" % 
                              (eulatext, version, response.code))
            raise DarkpointRESTException(response)