"""
.. module:: whitelist.py
   :platform: Unix, Windows
   :synopsis: Python client for Artifact Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>


"""
import requests
import json
import logging
from darkpointrest.exceptions import DarkpointRESTException


class Whitelist(object):

    def __init__(self, darkpoint_server, auth_cookie):
        raise NotImplementedError

        # self.darkpoint_server = darkpoint_server
        # self.auth_cookie = auth_cookie
        self.logger = logging.getLogger('darkpointrest.whitelist')

    def add(self):
        """
        Summary:
            Updates whitelist for authenticated DarkPoint user

        Args:
            * **groups**:

        Returns:
            None

        Raises:
            DarkpointRestException: REST API error response

        """
        add_endpoint_url = 'http://%s/api/auth/whitelist' % self.darkpoint_server

        response = requests.post(add_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                data=json.dumps({"hashes": {
                                                    "sha1": "",
                                                    "adler32": "",
                                                    "sha224": "",
                                                    "sha384": "",
                                                    "crc32": "",
                                                    "whirlpool": "",
                                                    "sha256": "c665cc3bbc094755a53f6e3b4f20fd61e9e2565f078e359107ec16da65c30676",
                                                    "sha512": "",
                                                    "ripemd160": "",
                                                    "md4": "",
                                                    "md5": ""
                                                  },
                                                "groupname": [
                                                    ""
                                                  ],
                                                "artifactHashes": {
                                                    "sha1": "",
                                                    "adler32": "",
                                                    "sha224": "",
                                                    "sha384": "",
                                                    "crc32": "",
                                                    "whirlpool": "",
                                                    "sha256": "c665cc3bbc094755a53f6e3b4f20fd61e9e2565f078e359107ec16da65c30676",
                                                    "sha512": "",
                                                    "ripemd160": "",
                                                    "md4": "",
                                                    "md5": ""
                                                  }}),
                                allow_redirects=False)

        if response.code is 200:
            self.logger.info("Successfully updated whitelist (%s)" % response.code)
        else:
            self.logger.error("Failed to update whitelist (%s)" % response.code)
            raise DarkpointRESTException(response, response.text)


    def delete(self):
        """
        Summary:
            Retrieves whitelist for authenticated DarkPoint user

        Args:
            None

        Returns:
            Whitelist

        Raises:
            DarkpointRestException: REST API error response

        """
        delete_endpoint_url = 'http://%s/api/auth/whitelist' % self.darkpoint_server

        response = requests.delete(delete_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                data=json.dumps({"hashes": {
                                                    "sha1": "",
                                                    "adler32": "",
                                                    "sha224": "",
                                                    "sha384": "",
                                                    "crc32": "",
                                                    "whirlpool": "",
                                                    "sha256": "c665cc3bbc094755a53f6e3b4f20fd61e9e2565f078e359107ec16da65c30676",
                                                    "sha512": "",
                                                    "ripemd160": "",
                                                    "md4": "",
                                                    "md5": ""
                                                  },
                                                "groupname": [
                                                    ""
                                                  ],
                                                "artifactHashes": {
                                                    "sha1": "",
                                                    "adler32": "",
                                                    "sha224": "",
                                                    "sha384": "",
                                                    "crc32": "",
                                                    "whirlpool": "",
                                                    "sha256": "c665cc3bbc094755a53f6e3b4f20fd61e9e2565f078e359107ec16da65c30676",
                                                    "sha512": "",
                                                    "ripemd160": "",
                                                    "md4": "",
                                                    "md5": ""
                                                  }}),
                                allow_redirects=False)

        if response.code is 200:
            self.logger.info("Successfully delete whitelist (%s)" % response.code)
            return response.content
        else:
            self.logger.error("Failed to delete whitelist (%s)" % response.code)
            raise DarkpointRESTException(response, response.text)
