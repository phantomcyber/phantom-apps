"""
.. module:: artifact.py
   :platform: Unix, Windows
   :synopsis: Python client for Artifact Controller of Darkpoint REST API.

.. moduleauthor:: Fred Wolfinger <fwolfinger@cyberpointllc.com>

"""
import unirest
import os
import bz2
import json
from hashlib import sha1
import base64
import uuid
import logging
from darkpointrest.exceptions import DarkpointRESTException
from darkpointrest.exceptions.validation import ValidationError
from darkpointrest.controllers.user import User


class IncludeExcludeOnly(object):
    """
    Summary:
        Class representing enumerated values of IncludeExcludeOnly fields.

    Members:
        * **INCLUDE**
        * **EXCLUDE**
        * **ONLY**
    """
    def __init__(self):

        self.INCLUDE = 'include'
        self.EXCLUDE = 'exclude'
        self.ONLY = 'only'


class Sort(object):
    """
    Summary:
        Class representing enumerated values of Sort fields.

    Members:
        * **ORIGINALSIZE**
        * **BZ2SIZE**
        * **ADLER32**
        * **CRC32**
        * **SHA224**
        * **SHA256**
        * **SHA384**
        * **SHA512**
        * **WHIRPOOL**
        * **MD4**
        * **MD5**
        * **RIPEMD160**
        * **TYPEDARKPOINT**
        * **TYPEMIME**
        * **TYPEDESCRIPTION**
        * **HASREMEDIATION**
        * **HASVIRUS**
        * **HASPACKER**
        * **HASPOTENTIALVIRUS**
        * **HASVIRUSCHILD**
        * **HASPACKERCHILD**
        * **HASPOTENTIALVIRUSCHILD**
        * **HIGHESTMALWARERATING**
        * **SCORE**
        * **DARKPOINTSCORE**
        * **DESCENDENTS**
        * **PROCESSED**
        * **UPDATED**
        * **ARCHIVED**
        * **UPLOADED**
        * **PROMOTED**
        * **SHARED**
        * **ALIAS**
        * **INGESTTIME**
        * **COLLECTTIME**
        * **UID**
        * **FILENAME**
        * **FILEPATH**
        * **HUNTER**
    """
    def __init__(self):
        self.ORIGINALSIZE = "originalSize"
        self.BZ2SIZE = "bz2Size"
        self.ADLER32 = "adler32"
        self.CRC32 = "crc32"
        self.SHA224 = "sha224"
        self.SHA256 = "sha256"
        self.SHA384 = "sha384"
        self.SHA512 = "sha512"
        self.WHIRPOOL = "whirlpool"
        self.MD4 = "md4"
        self.MD5 = "md5"
        self.RIPEMD160 = "ripemd160"
        self.TYPEDARKPOINT = "typeDarkpoint"
        self.TYPEMIME = "typeMime"
        self.TYPEDESCRIPTION = "typeDescription"
        self.HASREMEDIATION = "hasRemediation"
        self.HASVIRUS = "hasVirus"
        self.HASPACKER = "hasPacker"
        self.HASPOTENTIALVIRUS = "hasPotentialVirus"
        self.HASVIRUSCHILD = "hasVirusChild"
        self.HASPACKERCHILD = "hasPackerChild"
        self.HASPOTENTIALVIRUSCHILD = "hasPotentialVirusChild"
        self.HIGHESTMALWARERATING = "highestMalwareRating"
        self.SCORE = "score"
        self.DARKPOINTSCORE = "darkpointScore"
        self.DESCENDENTS = "descendents"
        self.PROCESSED = "processed"
        self.UPDATED = "updated"
        self.ARCHIVED = "archived"
        self.UPLOADED = "uploaded"
        self.PROMOTED = "promoted"
        self.SHARED = "shared"
        self.ALIAS = "alias"
        self.INGESTTIME = "ingestTime"
        self.COLLECTTIME = "collectTime"
        self.UID = "uid"
        self.FILENAME = "filename"
        self.FILEPATH = "filepath"
        self.HUNTER = "hunter"


class Scopes(object):
    """
    Summary:
        Container class representing fields/values of the **scopes** field for :py:meth:`.get_artifact_entries`.

    Members:
        * **group**: Artifacts belonging to this group will be included
        * **shared**: Specify whether **include**, **exclude**, or **only** consider shared artifacts \
        (see enum class :py:class:`.IncludeExcludeOnly`)
        * **hidden**: Specify whether **include**, **exclude**, or **only** consider hidden artifacts \
        (see enum class :py:class:`.IncludeExcludeOnly`)
        * **starred**: Specify whether **include**, **exclude**, or **only** consider starred artifacts \
        (see enum class :py:class:`.IncludeExcludeOnly`)

    """
    def __init__(self, groups=[], shared="", hidden="", starred=""):
        """
        Raises:
            ValidationError: If groups is not a string or list of length 1
        """
        self.scopes_dict = {}
        if len(groups) == 0:
            groups = self.user.get_current_groups()
        elif isinstance(groups, basestring):
            groups = [groups]
        elif len(groups) > 1:
            raise ValidationError("group must be a string or list of length 1")

        self.scopes_dict["groups"] = groups
        if shared is not "":
            assert(shared in IncludeExcludeOnly().__dict__.values())
        if hidden is not "":
            assert(hidden in IncludeExcludeOnly().__dict__.values())
        if starred is not "":
            assert(starred in IncludeExcludeOnly().__dict__.values())

        self.scopes_dict["shared"] = shared
        self.scopes_dict["hidden"] = hidden
        self.scopes_dict["promoted"] = starred
        self.scopes_dict["allUsers"] = False # don't know that we need this one
        #self.scopes_dict["users"] = [] # don't think we need this one given it only got added before if users wasn't empty list
        

    def __str__(self):
        return str(self.scopes_dict)


class WorkOrderRequest(object):
    """
    Summary:
        Container class for a Workflow work order request

    Members:
        * **sha1**: SHA1 of the artifact for which a work order request will be submitted
        * **workflow_id**: ID of the workflow to be run on the artifact
        * **analyzers**: In lieu of a workflow ID, a list of individual analyzers that will \
        be invoked on the artifact
        * **options**: A dictionary of custom options for the work order request
    """
    def __init__(self, sha1, workflow_id=None, analyzers=[], options=None):
        assert((workflow_id is not None) or (analyzers is not []))
        self.work_order_request_dict = {}
        self.work_order_request_dict["requestId"] = uuid.uuid1()
        self.work_order_request_dict["sha1"] = sha1
        self.work_order_request_dict["workflowId"] = workflow_id
        if analyzers:
            self.work_order_request_dict["analyzers"] = analyzers
        if options:
            self.work_order_request_dict["options"] = options

    def __str__(self):
        return str(self.work_order_request_dict)


class Artifact(object):

    def __init__(self, darkpoint_server, auth_cookie):
        self.darkpoint_server = darkpoint_server
        self.auth_cookie = auth_cookie
        self.logger = logging.getLogger('darkpointrest.artifact')
        self.user = User(darkpoint_server, auth_cookie)


    def create_scopes(self, group=None, shared="", hidden="", starred=""):
        """
        Summary:
            Create a :py:class:`.Scopes` object used in artifact retrieval

        Args:
            * **group**: Group to include in artifact search [required]
            * **shared**: Consider shared artifacts (one of `include`, `exclude`, or `only`) [optional]
            * **hidden**: Consider hidden artifacts (one of `include`, `exclude`, or `only`) [optional]
            * **starred**: Consider starred artifacts (one of `include`, `exclude`, or `only`) [optional]

        Returns:
            Populated :py:class:`.Scopes` object

        Raises:
            DarkpointRestException: REST API error response
            ValidationError: If group is not a string or list of length 1

        """
        if group is None:
            raise ValidationError("group parameter is required")
        if not isinstance(group, basestring):
            raise ValidationError("group parameter must be a string")
        
        return Scopes(groups=[group], shared=shared, hidden=hidden, starred=starred)


    def create_work_order_request(self, sha1, workflow_id=None, analyzers=[], options=None):
        """
        Summary:
            Create a Workflow :py:class:`.WorkOrderRequest` object

        Args:
            * **sha1**: The SHA1 of the artifact on which to operate
            * **workflow_id**: Specific workflow ID to run on the SHA1 [optional]
            * **analyzers**: In the absence of a workflow ID, a list of analyzers \
            to run on the SHA1 [optional]
            * **options**: Dictionary of additional valid WorkOrderRequest options [optional]

        Returns:
            Populated :py:class:`.WorkOrderRequest` object

        Raises:
            DarkpointRestException: REST API error response

        """
        return WorkOrderRequest(sha1, workflow_id, analyzers, options)


    def upload(self, filename, data=None, darkpoint_type="", hunter='Python REST Client',
               skip_workflows=False, run_workflows=[], callback=None):
        """
        Summary:
            Uploads a file to DarkPoint

        Args:
            * **filename**: Full filesystem path of the file to be uploaded
            * **data**: Raw uncompressed data to be uploaded with name as filename [optional]
            * **darkpoint_type**: Artifact type [optional]
            * **hunter**: Override default hunter designation ('Python REST Client') [optional]
            * **skip_workflows**: Skip running the default DarkPoint workflows on this artifact [optional]
            * **run_workflows**: List of :py:class:`.WorkOrderRequest` objects to be run on this artifact. \
            Use the :py:meth:`.create_work_order_request` function to create each of the necessary \
            :py:class:`.WorkOrderRequest` objects with the desired values [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            SHA1 of the file on success

        Raises:
            DarkpointRestException: REST API error response

        """
        upload_endpoint_url = self.darkpoint_server + '/api/auth/artifact/upload'

        if not data:
            with open(filename, 'rb') as upload_file:
                data = upload_file.read()

        upload_sha1 = sha1(data).hexdigest()

        run_workflows = [wor.work_order_request_dict for wor in run_workflows]

        response = unirest.post(upload_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                        'Cookie': self.auth_cookie,
                                        'Content-Type': 'application/json'},
                                params=json.dumps({'metaData': {
                                        'size': len(data),
                                        'fileName': os.path.basename(filename),
                                        'hunter': hunter,
                                        'sha1':  upload_sha1,
                                        'darkpointType': darkpoint_type,
                                        'skipWorkflows': skip_workflows,
                                        'runWorkflows': run_workflows},
                                        'fileData': base64.b64encode(bz2.compress(data)) }),
                                callback=callback)

        if response.code is 200:
            self.logger.info("Upload successful: %s (%s)" % (filename, response.code))
            self.logger.info("Upload SHA1: %s" % upload_sha1)
            return response.body["sha1"]
        else:
            self.logger.error("Upload failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def download(self, sha1, path=None, callback=None):
        """
        Summary:
            Downloads a file from DarkPoint

        Args:
            * **sha1**: SHA1 of the DarkPoint file to be downloaded
            * **path**: Path of where to write the file named with the SHA1 with contents \
            bz2-compressed [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            bz2-compressed data

        Raises:
            DarkpointRestException: REST API error response

        """
        download_endpoint_url = self.darkpoint_server + '/api/auth/artifact/download/' + sha1

        response = unirest.get(download_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/octet-stream'},
                              callback=callback)

        if response.code is 200:
            self.logger.info("Download successful (%s)" % response.code)
            if path:
                if not os.path.exists(path):
                    os.makedirs(path)
                with open(os.path.join(path,sha1+".bz2"), 'wb') as download_file:
                    download_file.write(response.body)
                self.logger.info("File written to: %s" % os.path.join(path,sha1+".bz2"))
            return response.body
        else:
            self.logger.error("Download failed (%s)" % response.code)
            raise DarkpointRESTException(response, "Download error")


    def get_sha1s(
            self,
            path=None,
            callback=None,
            sort="updated",
            group=None,
            shared=False,
            hidden=False,
            starred=False,
            reverse=True,
            limit=1000,
            offset=0):
        """
        Summary:
            Gets a list of sha1s for the logged-in user

        Args:
            path (str): (Optional) Can write results directly to this output file
            callback (function): (Optional) User-defined callback function for asynchronous operation
            sort (str): (Optional) A sort choice, one of - "ingestTime", "darkpointScore",
                        "descendents", "filename", "originalSize"
            group (str): (Optional) The group to use; defaults to the current group
            shared (boolean): (Optional) Indicate if shared items are included
            hidden (boolean): (Optional) Indicate if hidden items are included
            starred (boolean): (Optional) Indicate if starred items are included
            reverse (boolean): (Optional) Reverses the sorting of the returned artifact list
            limit (int): (Optional) Sets the max number of results to return
            offset (int): (Optional) Advances into the returned list this amount

        Returns:
            list: A list of SHA1s

        Raises:
            DarkpointRestException: REST API error response
            ValidationError: If group is not a string or list of length 1

        """
        sha1s_endpoint_url = self.darkpoint_server + '/api/auth/artifact/sha1s'

        if group is None:
            group = self.user.get_current_groups()[0]
        if not isinstance(group, basestring):
            raise ValidationError("group parameter must be a string")

        scopes = {"groups": [group.upper()]}

        if shared:
            scopes["shared"] = "only"
        if hidden:
            scopes["hidden"] = "only"
        if starred:
            scopes["promoted"] = "only"

        body = {
            "sort": sort,
            "scopes": scopes,
            "reverse": reverse,
            "limit": limit,
            "offset": offset
        }

        response = unirest.post(
            sha1s_endpoint_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'},
            params=json.dumps(body),
            callback=callback
        )

        if response.code is 200:
            self.logger.info("SHA1 list retrieval successful (%s)" % response.code)
            sha1_list = response.body
            if path:
                output_file = os.path.join(path, "sha1s.json")
                if not os.path.exists(path):
                    os.makedirs(path)
                with open(output_file, 'w') as download_file:
                    download_file.write(json.dumps(sha1_list))
                self.logger.info("Outline written to: %s" % output_file)
            return sha1_list
        else:
            self.logger.error("SHA1 list retrieval failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_artifact_outline(self, sha1, path=None, callback=None):
        """
        Summary:
            Gets an artifact outline from DarkPoint

        Args:
            * **sha1**: SHA1 of the DarkPoint outline to be downloaded. Will also \
            be used as the file name
            * **path**: Path of where to write the file [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Artifact outline as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        outline_endpoint_url = self.darkpoint_server + '/api/auth/artifact/outline'

        response = unirest.post(outline_endpoint_url,
                                headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/json'},
                                params=json.dumps([sha1]),
                                callback=callback)

        if response.code is 200:
            self.logger.info("Artifact outline retrieval successful (%s)" % response.code)
            artifact_outline = response.body
            if path:
                output_file = os.path.join(path,sha1+".json")
                if not os.path.exists(path):
                    os.makedirs(path)
                with open(output_file, 'w') as download_file:
                    download_file.write(json.dumps(artifact_outline))
                self.logger.info("Outline written to: %s" % output_file)
            return artifact_outline
        else:
            self.logger.error("Download failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_artifact_entries(self, **kwargs):
        """
        Summary:
            Gets section(s) of an artifact entry from DarkPoint

        Args:
            * **sha1s**: List of SHA1s to be retrieved. Will also be used \
            as the file name(s) [optional]
            * **sections**: List of section names to retrieve [optional]
            * **scopes**: Class object that defines a dictionary of various scopes that \
            can be used to reduce or expand the search space for locating artifacts. Use \
            the :py:meth:`.create_scopes` function to create the necessary :py:class:`.Scopes` object \
            with the desired values [optional]
            * **sort**: Specify sort method for returned results (see :py:class:`.Sort` class) [optional]
            * **reverse**: Reverse the sort order of returned results [optional]
            * **offset**: Specify result offset from which to begin paging [optional]
            * **limit**: Limit the number of returned results [optional]
            * **path**: Path of where to write the file(s) [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Section(s) per SHA1 as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        entries_endpoint_url = self.darkpoint_server + '/api/auth/artifact/entries'

        body = {}

        if "callback" in kwargs:
            callback = kwargs["callback"]
            kwargs.pop("callback")
        else:
            callback = None

        if "sort" in kwargs:
            assert(kwargs["sort"] in Sort.__dict__.values())

        if "scopes" in kwargs:
            assert(type(kwargs["scopes"]) is Scopes)
            body["scopes"] = kwargs["scopes"].scopes_dict
            kwargs.pop("scopes")

        if "sha1s" not in kwargs:
            body["sha1s"] = []

        if "sections" not in kwargs:
            body["sections"] = ['inbox','analysis','metadata','ingest']

        for key, value in kwargs.iteritems():
            if key != "path":
                body[key] = value

        response = unirest.post(entries_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/json'},
                              params=json.dumps(body),
                              callback=callback)

        if response.code is 200:
            self.logger.info("Artifact entry list retrieval successful (%s)" % response.code)

            if "path" in kwargs:
                if not os.path.exists(kwargs["path"]):
                    os.makedirs(kwargs["path"])
                for res in response.body:
                    sha1 = res["sha1"]
                    output_file = os.path.join(kwargs["path"],sha1+".json")
                    with open(output_file, 'w') as download_file:
                        download_file.write(json.dumps(res))
                    self.logger.info("Artifact entries written to: %s" % output_file)
            return response.body
        else:
            self.logger.error("Download failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_artifact_analyzer_binary(self, sha1, analyzer, version, key, filename=None, extension=None, path=None, callback=None):
        """
        Summary:
            Gets a binary artifact from an analyzer for an artifact from DarkPoint

        Args:
            * **sha1**: SHA1 of artifact
            * **analyzer**: The analyzer to access
            * **version**: The analyzer version to access
            * **key**: The key to use
            * **filename**: The filename to access [optional unless extension passed]
            * **extension**: The extension to access [optional unless filename passed]
            * **path**: Path of where to write the file named with the SHA1 with contents \
            (may be compressed) [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            binary artifact data

        Raises:
            DarkpointRestException: REST API error response
            ValidationError: If only one of filename or extension is passed, but not both

        """
        if filename and extension:
            binary_endpoint_url = self.darkpoint_server + '/api/auth/artifact/analyzer-binary/{sha1}/{bucket}/{version}/{key}/{fileName}/{extension}'.format(sha1=sha1,bucket=analyzer,version=version,key=key,fileName=filename,extension=extension)
        elif filename or extension:
            raise ValidationError("Both filename and extension must be passed together")
        else:
            binary_endpoint_url = self.darkpoint_server + '/api/auth/artifact/analyzer-binary/{sha1}/{bucket}/{version}/{key}'.format(sha1=sha1,bucket=analyzer,version=version,key=key)

        response = unirest.get(binary_endpoint_url,
                              headers={'darkpoint-source': 'python/restclient',
                                      'Cookie': self.auth_cookie,
                                      'Content-Type': 'application/json',
                                      'Accept': 'application/octet-stream'},
                              callback=callback)

        if response.code is 200:
            self.logger.info("Binary artifact retrieval successful (%s)" % response.code)
            if path:
                if not os.path.exists(path):
                    os.makedirs(path)
                with open(os.path.join(path,sha1), 'wb') as download_file:
                    download_file.write(response.body)
                self.logger.info("File written to: %s" % os.path.join(path,sha1+".bz2"))
            return response.body
        else:
            self.logger.error("Binary artifact retrieval failed (%s)" % response.code)
            raise DarkpointRESTException(response, "Download error")


    def get_family(self, sha1, callback=None):
        """
        Summary:
            Get the family associated with this sha1

        Args:
            * **sha1**: SHA1 of the artifact to retrieve family information.
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Family information as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        family_endpoint_url = self.darkpoint_server + '/api/auth/artifact/family/' + sha1

        response = unirest.get(
            family_endpoint_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Artifact family information retrieval successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Artfiact family information retrieval failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def get_annotation(self, sha1, callback=None):
        """
        Summary:
            Get the annotations associated with this sha1

        Args:
            * **sha1**: SHA1 of the artifact to retrieve annotations for
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Annotations information as JSON list

        Raises:
            DarkpointRestException: REST API error response

        """
        annotations_endpoint_url = self.darkpoint_server + '/api/auth/artifact/annotations/' + sha1

        response = unirest.get(
            annotations_endpoint_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Artifact annotation information retrieval successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Artfiact annotation information retrieval failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def set_annotation(self, sha1, annotation, annotation_id=None, callback=None):
        """
        Summary:
            Adds a new annotation to an artifact

        Args:
            * **sha1**: SHA1 of the artifact
            * **annotation**: Annotation to add
            * **annotation_id**: If updating an existing annotation
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Status of operation as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        set_annotation_url = self.darkpoint_server + '/api/auth/artifact/annotation'

        annotation_params = {
            'sha1': sha1,
            'annotation': annotation
        }

        if annotation_id:
            annotation_params['id'] = annotation_id

        response = unirest.post(
            set_annotation_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            params=json.dumps(annotation_params),
            callback=callback)

        if response.code is 200:
            self.logger.info("Artifact annotation set successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Artifact annotation set failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def delete_annotation(self, annotation_id, callback=None):
        """
        Summary:
            Delete the annotation by 'id'

        Args:
            * **annotation_id**: id of the annotation to delete from the system
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Status of operation as JSON

        Raises:
            DarkpointRestException: REST API error response

        """
        annotations_endpoint_url = self.darkpoint_server + '/api/auth/artifact/annotation/' + str(annotation_id)

        response = unirest.delete(
            annotations_endpoint_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Artifact annotation deletion successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Artfiact annotation deletion failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def update_artifact(self, sha1, group=None, shared=None, tags=None, alias=None,
                        replaceTags=None, hidden=None, starred=None, callback=None):
        """
        Summary:
            Updates an artifact's system meta data.

        Args:
            * **sha1**: SHA1 of the DarkPoint artifact to update
            * **group**: String of group name that the update action applies to; defaults to the current group [optional]
            * **shared**: List of users to share this artifact with [optional]
            * **tags**: List of tags to apply to this artifact [optional]
            * **alias**: String to 'alias' this artifact to [optional]
            * **replaceTags**: If 'False' append to the tags with those provided instead of replacing [optional]
            * **hidden**: If 'True' hide the artifact from the main artifacts page (still available via search) [optional]
            * **starred**: If 'True' star the artifact to show it in the starred scope on the artifacts page [optional]
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            Status of operation as JSON

        Raises:
            DarkpointRestException: REST API error response
            ValidationError: If group is not a string

        """
        update_artifact_url = self.darkpoint_server + '/api/auth/artifact/update'

        if group is None:
            group = self.user.get_current_groups()[0]
        if not isinstance(group, basestring):
            raise ValidationError("group parameter must be a string")
            
        params = {'sha1': sha1, 'groups': [group.upper()]}

        if shared:
            params['shared'] = shared
        if tags:
            params['tags'] = tags
        if alias:
            params['alias'] = alias
        if replaceTags is not None:
            params['replaceTags'] = replaceTags
        if hidden is not None:
            params['hidden'] = hidden
        if starred is not None:
            params['promoted'] = starred

        response = unirest.post(
            update_artifact_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'},
            params=json.dumps(params),
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Artifact update successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Artifact update failed (%s)" % response.code)
            raise DarkpointRESTException(response)


    def tag_search(self, tag, callback=None):
        """
        Summary:
            Perform a tag search

        Args:
            * **tag**: Artifact tag to search on
            * **callback**: User-defined callback function for asynchronous operation [optional]

        Returns:
            List of artifact SHA-1s containing the requested tag;
            Empty string if no results returned

        Raises:
            DarkpointRestException: REST API error response

        """
        tag_search_endpoint_url = self.darkpoint_server + '/api/auth/artifact/tag/' + tag

        response = unirest.get(
            tag_search_endpoint_url,
            headers={
                'darkpoint-source': 'python/restclient',
                'Cookie': self.auth_cookie,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            callback=callback
        )

        if response.code is 200:
            self.logger.info("Tag search was successful (%s)" % response.code)
            return response.body
        else:
            self.logger.error("Tag search failed (%s)" % response.code)
            raise DarkpointRESTException(response)